#include <iostream>
#include <memory>
#include <string>
#include <grpcpp/grpcpp.h>

#include "calculator.grpc.pb.h"

using grpc::Channel;
using grpc::ClientContext;
using grpc::Status;
using calculator::AddRequest;
using calculator::AddResponse;
using calculator::SubtractRequest;
using calculator::SubtractResponse;
using calculator::MultiplyRequest;
using calculator::MultiplyResponse;
using calculator::DivideRequest;
using calculator::DivideResponse;
using calculator::Calculator;

// 客户端类
class CalculatorClient {
 public:
  CalculatorClient(std::shared_ptr<Channel> channel)
      : stub_(Calculator::NewStub(channel)) {}

  // 加法
  int Add(int a, int b) {
    AddRequest request;
    request.set_a(a);
    request.set_b(b);

    AddResponse response;
    ClientContext context;

    Status status = stub_->Add(&context, request, &response);

    if (status.ok()) {
      return response.result();
    } else {
      std::cout << status.error_code() << ": " << status.error_message()
                << std::endl;
      return -1;
    }
  }

  // 减法
  int Subtract(int a, int b) {
    SubtractRequest request;
    request.set_a(a);
    request.set_b(b);

    SubtractResponse response;
    ClientContext context;

    Status status = stub_->Subtract(&context, request, &response);

    if (status.ok()) {
      return response.result();
    } else {
      std::cout << status.error_code() << ": " << status.error_message()
                << std::endl;
      return -1;
    }
  }

  // 乘法
  int Multiply(int a, int b) {
    MultiplyRequest request;
    request.set_a(a);
    request.set_b(b);

    MultiplyResponse response;
    ClientContext context;

    Status status = stub_->Multiply(&context, request, &response);

    if (status.ok()) {
      return response.result();
    } else {
      std::cout << status.error_code() << ": " << status.error_message()
                << std::endl;
      return -1;
    }
  }

  // 除法
  float Divide(int a, int b) {
    DivideRequest request;
    request.set_a(a);
    request.set_b(b);

    DivideResponse response;
    ClientContext context;

    Status status = stub_->Divide(&context, request, &response);

    if (status.ok()) {
      return response.result();
    } else {
      std::cout << status.error_code() << ": " << status.error_message()
                << std::endl;
      return -1.0f;
    }
  }

 private:
  std::unique_ptr<Calculator::Stub> stub_;
};

int main(int argc, char**argv) {
  // 连接到服务器
  CalculatorClient client(grpc::CreateChannel(
      "localhost:50051", grpc::InsecureChannelCredentials()));
  
  // 测试各种运算
  int add_result = client.Add(10, 5);
  std::cout << "10 + 5 = " << add_result << std::endl;

  int sub_result = client.Subtract(10, 5);
  std::cout << "10 - 5 = " << sub_result << std::endl;

  int mul_result = client.Multiply(10, 5);
  std::cout << "10 * 5 = " << mul_result << std::endl;

  float div_result = client.Divide(10, 5);
  std::cout << "10 / 5 = " << div_result << std::endl;

  return 0;
}
