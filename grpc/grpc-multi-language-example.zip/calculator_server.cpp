#include <iostream>
#include <memory>
#include <string>
#include <grpcpp/grpcpp.h>

#include "calculator.grpc.pb.h"

using grpc::Server;
using grpc::ServerBuilder;
using grpc::ServerContext;
using grpc::Status;
using calculator::AddRequest;
using calculator::AddResponse;
using calculator::SubtractRequest;
using calculator::SubtractResponse;
using calculator::MultiplyRequest;
using calculator::MultiplyResponse;
using calculator::DivideRequest;
using calculator::DivideResponse;
using calculator::Calculator;

// 实现Calculator服务
class CalculatorServiceImpl final : public Calculator::Service {
  Status Add(ServerContext* context, const AddRequest* request,
             AddResponse* response) override {
    int32_t result = request->a() + request->b();
    std::cout << "收到加法请求: " << request->a() << " + " << request->b() << std::endl;
    response->set_result(result);
    return Status::OK;
  }

  Status Subtract(ServerContext* context, const SubtractRequest* request,
             SubtractResponse* response) override {
    int32_t result = request->a() - request->b();
    std::cout << "收到减法请求: " << request->a() << " - " << request->b() << std::endl;
    response->set_result(result);
    return Status::OK;
  }

  Status Multiply(ServerContext* context, const MultiplyRequest* request,
             MultiplyResponse* response) override {
    int32_t result = request->a() * request->b();
    std::cout << "收到乘法请求: " << request->a() << " * " << request->b() << std::endl;
    response->set_result(result);
    return Status::OK;
  }

  Status Divide(ServerContext* context, const DivideRequest* request,
             DivideResponse* response) override {
    std::cout << "收到除法请求: " << request->a() << " / " << request->b() << std::endl;
    if (request->b() == 0) {
      return Status(grpc::StatusCode::INVALID_ARGUMENT, "除数不能为零");
    }
    float result = static_cast<float>(request->a()) / request->b();
    response->set_result(result);
    return Status::OK;
  }
};

void RunServer() {
  std::string server_address("0.0.0.0:50051");
  CalculatorServiceImpl service;

  ServerBuilder builder;
  // 监听端口，不使用TLS
  builder.AddListeningPort(server_address, grpc::InsecureServerCredentials());
  // 注册服务
  builder.RegisterService(&service);
  // 构建并启动服务器
  std::unique_ptr<Server> server(builder.BuildAndStart());
  std::cout << "C++ gRPC服务器启动，监听端口" << server_address << std::endl;

  // 等待服务器关闭
  server->Wait();
}

int main(int argc, char**argv) {
  RunServer();
  return 0;
}
