package main

import (
	"context"
	"fmt"
	"log"
	"net"

	pb "github.com/yourusername/grpc-example/calculator" // 替换为你的实际路径
	"google.golang.org/grpc"
)

// 实现Calculator服务接口
type server struct {
	pb.UnimplementedCalculatorServer
}

// 加法实现
func (s *server) Add(ctx context.Context, in *pb.AddRequest) (*pb.AddResponse, error) {
	log.Printf("收到加法请求: %d + %d", in.A, in.B)
	return &pb.AddResponse{Result: in.A + in.B}, nil
}

// 减法实现
func (s *server) Subtract(ctx context.Context, in *pb.SubtractRequest) (*pb.SubtractResponse, error) {
	log.Printf("收到减法请求: %d - %d", in.A, in.B)
	return &pb.SubtractResponse{Result: in.A - in.B}, nil
}

// 乘法实现
func (s *server) Multiply(ctx context.Context, in *pb.MultiplyRequest) (*pb.MultiplyResponse, error) {
	log.Printf("收到乘法请求: %d * %d", in.A, in.B)
	return &pb.MultiplyResponse{Result: in.A * in.B}, nil
}

// 除法实现
func (s *server) Divide(ctx context.Context, in *pb.DivideRequest) (*pb.DivideResponse, error) {
	log.Printf("收到除法请求: %d / %d", in.A, in.B)
	if in.B == 0 {
		return nil, fmt.Errorf("除数不能为零")
	}
	return &pb.DivideResponse{Result: float32(in.A) / float32(in.B)}, nil
}

func main() {
	// 监听50051端口
	lis, err := net.Listen("tcp", ":50051")
	if err != nil {
		log.Fatalf("无法监听端口: %v", err)
	}
	
	// 创建gRPC服务器
	s := grpc.NewServer()
	
	// 注册服务
	pb.RegisterCalculatorServer(s, &server{})
	
	log.Println("Golang gRPC服务器启动，监听端口50051...")
	if err := s.Serve(lis); err != nil {
		log.Fatalf("服务器启动失败: %v", err)
	}
}
