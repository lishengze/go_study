import logging

import grpc
import calculator_pb2
import calculator_pb2_grpc

def run():
    """gRPC客户端主函数"""
    # 连接到gRPC服务器
    with grpc.insecure_channel('localhost:50051') as channel:
        stub = calculator_pb2_grpc.CalculatorStub(channel)
        
        # 测试加法
        add_response = stub.Add(calculator_pb2.AddRequest(a=10, b=5))
        print(f"10 + 5 = {add_response.result}")
        
        # 测试减法
        sub_response = stub.Subtract(calculator_pb2.SubtractRequest(a=10, b=5))
        print(f"10 - 5 = {sub_response.result}")
        
        # 测试乘法
        mul_response = stub.Multiply(calculator_pb2.MultiplyRequest(a=10, b=5))
        print(f"10 * 5 = {mul_response.result}")
        
        # 测试除法
        div_response = stub.Divide(calculator_pb2.DivideRequest(a=10, b=5))
        print(f"10 / 5 = {div_response.result}")

if __name__ == '__main__':
    logging.basicConfig()
    run()
