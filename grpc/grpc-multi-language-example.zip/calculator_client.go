package main

import (
	"context"
	"fmt"
	"log"

	pb "github.com/yourusername/grpc-example/calculator" // 替换为你的实际路径
	"google.golang.org/grpc"
)

func main() {
	// 连接到gRPC服务器
	conn, err := grpc.Dial(":50051", grpc.WithInsecure())
	if err != nil {
		log.Fatalf("无法连接到服务器: %v", err)
	}
	defer conn.Close()
	
	// 创建客户端
	c := pb.NewCalculatorClient(conn)
	
	// 测试加法
	addResp, err := c.Add(context.Background(), &pb.AddRequest{A: 10, B: 5})
	if err != nil {
		log.Fatalf("加法请求失败: %v", err)
	}
	fmt.Printf("10 + 5 = %d\n", addResp.Result)
	
	// 测试减法
	subResp, err := c.Subtract(context.Background(), &pb.SubtractRequest{A: 10, B: 5})
	if err != nil {
		log.Fatalf("减法请求失败: %v", err)
	}
	fmt.Printf("10 - 5 = %d\n", subResp.Result)
	
	// 测试乘法
	mulResp, err := c.Multiply(context.Background(), &pb.MultiplyRequest{A: 10, B: 5})
	if err != nil {
		log.Fatalf("乘法请求失败: %v", err)
	}
	fmt.Printf("10 * 5 = %d\n", mulResp.Result)
	
	// 测试除法
	divResp, err := c.Divide(context.Background(), &pb.DivideRequest{A: 10, B: 5})
	if err != nil {
		log.Fatalf("除法请求失败: %v", err)
	}
	fmt.Printf("10 / 5 = %f\n", divResp.Result)
}
