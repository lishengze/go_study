import logging

import grpc
import calculator_pb2
import calculator_pb2_grpc

class CalculatorServicer(calculator_pb2_grpc.CalculatorServicer):
    """实现Calculator服务的类"""
    
    def Add(self, request, context):
        """加法实现"""
        result = request.a + request.b
        print(f"收到加法请求: {request.a} + {request.b}")
        return calculator_pb2.AddResponse(result=result)
    
    def Subtract(self, request, context):
        """减法实现"""
        result = request.a - request.b
        print(f"收到减法请求: {request.a} - {request.b}")
        return calculator_pb2.SubtractResponse(result=result)
    
    def Multiply(self, request, context):
        """乘法实现"""
        result = request.a * request.b
        print(f"收到乘法请求: {request.a} * {request.b}")
        return calculator_pb2.MultiplyResponse(result=result)
    
    def Divide(self, request, context):
        """除法实现"""
        print(f"收到除法请求: {request.a} / {request.b}")
        if request.b == 0:
            context.set_code(grpc.StatusCode.INVALID_ARGUMENT)
            context.set_details("除数不能为零")
            return calculator_pb2.DivideResponse()
        result = request.a / request.b
        return calculator_pb2.DivideResponse(result=result)

def serve():
    """启动gRPC服务器"""
    server = grpc.server(futures.ThreadPoolExecutor(max_workers=10))
    calculator_pb2_grpc.add_CalculatorServicer_to_server(CalculatorServicer(), server)
    server.add_insecure_port('[::]:50051')
    print("Python gRPC服务器启动，监听端口50051...")
    server.start()
    server.wait_for_termination()

if __name__ == '__main__':
    logging.basicConfig()
    import futures  # 导入需要放在这里以避免某些环境问题
    serve()
